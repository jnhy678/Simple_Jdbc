package com.controller;

import java.util.List;

import com.dto.MemberDto;
import com.service.MemberService;
import com.view.MemberView;

public class MemberController {
	MemberService mSev = new MemberService();
	MemberView mView = new MemberView();
	
	public void controll() {
		int sel = 0;//메뉴번호
		MemberDto member = null;//회원 정보 저장
		int lresult = 0;//로그인 성공 실패 저장
		String user = null;//로그인에 성공한 회원 ID 저장
		
		while(true) {
			//로그인 처리
			if(member == null) {
				//최초 로그인은 한번만 실행되도록 처리하는 부분.
				member = new MemberDto();
				mView.loginInput(member);
				lresult = mSev.loginCheck(member);
			}
			
			if(lresult == 0) {//로그인에 성공하면
				//성공한 회원의 아이디를 저장.
				user = member.getMid();
			}
			else {
				//로그인 실패.
				//로그인 실패 메시지 출력
				mView.printMsg(lresult);
				
				if(lresult == 9) {
					mView.regInput(member);
					int r = mSev.regMember(member);
					mView.printMsg(r);
				}
				
				member = null;//로그인 입력값 초기화.
				continue;
			}
			
			//로그인 성공하면 메뉴 출력
			mView.showMainMenu(user);
			sel = mView.inputNum();
			
			//종료 처리.
			if(sel == 0) {
				mView.printMsg(0);
				break;
			}
			
			//각 메뉴별 처리.
			switch(sel) {
			case 1:
				//내 정보 보기
				viewMyInfo(user);
				break;
			case 2:
				//내 정보 수정
				updateMyInfo(user);
				break;
			case 3:
				//관리자 메뉴. 전체 회원 정보 보기
				if(!user.equals("admin")) {
					mView.printMsg(2);
					break;
				}
				viewAllInfo();
				break;
			case 4:
				//관리자 메뉴. 회원 삭제
				if(!user.equals("admin")) {
					mView.printMsg(2);
					break;
				}
				deleteInfo();
				break;
			default:
				mView.printMsg(2);
			}
		}
	}

	private void deleteInfo() {
		String delId = mView.inputDelId("삭제할 ID: ");
		int result = mSev.delMember(delId);
		mView.printMsg(result);
	}

	private void updateMyInfo(String user) {
		// TODO Auto-generated method stub
		MemberDto member = mSev.memberInfo(user);
		mView.updateInput(member);
		int result = mSev.updateInfo(member);
		mView.printMsg(result);
	}

	private void viewAllInfo() {
		// TODO Auto-generated method stub
		mView.printAll(mSev.memberList());
	}

	private void viewMyInfo(String user) {
		// TODO Auto-generated method stub
		MemberDto member = mSev.memberInfo(user);
		//출력 -> view 클래스
		mView.printInfo(member);
	}
}





