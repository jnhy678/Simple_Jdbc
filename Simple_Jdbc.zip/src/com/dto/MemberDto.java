package com.dto;

public class MemberDto {
	//필드(변수)의 이름과 자료형은 DB 테이블과 맞춤.
	private String mid;
	private String mname;
	private String mpass;
	private String mgrade;
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMpass() {
		return mpass;
	}
	public void setMpass(String mpass) {
		this.mpass = mpass;
	}
	public String getMgrade() {
		return mgrade;
	}
	public void setMgrade(String mgrade) {
		this.mgrade = mgrade;
	}
	
	@Override
	public String toString() {
		String str = "ID: " + mid + "\n" 
				+ "NAME: " + mname + "\n" 
				+ "GRADE: " + mgrade + "\n";
		return str;
	}
}





