package com.service;

import java.util.ArrayList;
import java.util.List;

import com.dao.MemberDaoImpl;
import com.dto.MemberDto;

public class MemberService {
	//Service는 controller로 넘어온 기능을 수행
	//이때, DB 연동이 필요하면 DAO 클래스를 사용
	
	MemberDaoImpl mDao = new MemberDaoImpl();
	
	//로그인 처리용 메소드
	public int loginCheck(MemberDto member) {
		int result = 0;
		
		//DAO로부터 ID 검색 결과인 PASS 받기
		String pass = mDao.selectPass(member.getMid());
		
		//PASS를 받아서 로그인 처리
		if(pass != null) {
			if(pass.equals(member.getMpass())) {
				result = 0;//로그인 성공 
			}
			else {//비번 틀림.
				result = 10;//비번 틀림 메시지 번호
			}
		}
		else {//아이디 없음.
			result = 9;//아이디 없음 메시지 번호
		}
		
		return result;
	}
	
	//내 정보 보기 처리 메소드
	public MemberDto memberInfo(String mid) {
		MemberDto member = mDao.selectInfo(mid);
		
		return member;
	}
	
	//관리자용 전체 회원 정보 보기 처리 메소드
	public List<MemberDto> memberList(){
		List<MemberDto> mList = mDao.selectList();
		
		return mList;
	}

	public int updateInfo(MemberDto member) {
		int result = -1;
		result = mDao.updateMember(member);
		
		if(result > 0) {
			result = 4;//수정 내용 저장 완료 메시지 번호
		}
		
		return result;
	}

	public int delMember(String delId) {
		int result = -1;
		
		result = mDao.deleteMember(delId);
		
		if(result > 0) {
			result = 5;//삭제 완료 메시지 번호
		}
		
		return result;
	}

	public int regMember(MemberDto member) {
		int result = -1;
		
		result = mDao.insertMember(member);
		
		if(result > 0) {
			result = 4;
		}
		
		return result;
	}
}//클래스 끝








