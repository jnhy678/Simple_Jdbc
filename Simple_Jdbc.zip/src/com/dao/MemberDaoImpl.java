package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dto.MemberDto;

public class MemberDaoImpl implements MemberDao {
	//DAO 클래스는 select, insert, update, delete만 수행
	
	//DB 연동을 위한 준비작업
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	private String user = "DEV";
	private String password = "1234";
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	//생성자(드라이버 로드)
	public MemberDaoImpl() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 로드 실패");
		}
	}
	
	@Override
	public String selectPass(String mid) {
		//아이디와 비번을 확인
		//로그인 성공 : true
		//로그인 실패 : false
		String result = null;//결과전송용 변수
		
		String query = "SELECT mpass FROM mm WHERE mid=?";
		
		try {
			//1. DB 접속
			conn = DriverManager.getConnection(url, user, password);
			
			//2. Statement 생성
			pstmt = conn.prepareStatement(query);
			//3. 쿼리문 완성
			pstmt.setString(1, mid);
			//4. 쿼리문 실행( 및 결과 받기)
			rs = pstmt.executeQuery();
			
			//검색 결과는 1개 또는 없음.
			if(rs.next()) {
				result = rs.getString("mpass");
			}
			else {
				result = null;
			}
		} catch(SQLException e) {
			result = null;//안해줘도 됨..
		} finally {//DB 사용 완료 후 접속해제
			close();
		}
		
		return result;
	}

	@Override
	public MemberDto selectInfo(String mid) {
		// 로그인 한 ID로 DB 검색후 MemberDto 반환
		String query = "SELECT * FROM mm WHERE mid = ?";
		
		MemberDto member = null;
		
		try {
			conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, mid);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				//검색을 성공했을 때만 인스턴스를 생성.
				member = new MemberDto();
				member.setMid(rs.getString("mid"));
				member.setMname(rs.getString("mname"));
				member.setMpass(rs.getString("mpass"));
				member.setMgrade(rs.getString("mgrade"));				
			}
		} catch (SQLException e) {
			//
		} finally {//DB 사용 완료 후 접속해제
			close();
		}
		
		return member;
	}

	@Override
	public List<MemberDto> selectList() {
		// 관리자 메뉴에서 회원 전체 보기 메소드
		ArrayList<MemberDto> mList = 
				new ArrayList<MemberDto>();
		
		String query = "SELECT * FROM MM";
		
		try {
			conn = DriverManager
					.getConnection(url, user, password);
			pstmt = conn.prepareStatement(query);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				MemberDto m = new MemberDto();
				m.setMid(rs.getString("mid"));
				m.setMname(rs.getString("mname"));
				m.setMpass(rs.getString("mpass"));
				m.setMgrade(rs.getString("mgrade"));
				
				mList.add(m);
			}
			
		} catch (SQLException e) {
			
		} finally {
			close();
		}
		
		return mList;
	}

	@Override
	public int insertMember(MemberDto member) {
		int result = 0;
		String query = "INSERT INTO mm (mid, mname, mpass) "
				+ "VALUES (?, ?, ?)";
		
		try {
			conn = DriverManager.getConnection(url, user, password);
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, member.getMid());
			pstmt.setString(2, member.getMname());
			pstmt.setString(3, member.getMpass());
			
			result = pstmt.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			result = -1;
			
			try {
				conn.rollback();
			} catch (SQLException e1) {
				//e1.printStackTrace();
				result = -1;
			}
		} finally {
			close();
		}
		
		return result;
	}

	@Override
	public int updateMember(MemberDto member) {
		// TODO Auto-generated method stub
		int result = 0;
		String query = "UPDATE mm SET mname=?, mpass=? WHERE mid=?";
		
		try {
			conn = DriverManager.getConnection(url, user, password);
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, member.getMname());
			pstmt.setString(2, member.getMpass());
			pstmt.setString(3, member.getMid());
			
			result = pstmt.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			result = -1;
			
			try {
				conn.rollback();
			} catch (SQLException e1) {
				//e1.printStackTrace();
				result = -1;
			}
		} finally {
			close();
		}
		
		return result;
	}

	@Override
	public int deleteMember(String mid) {
		int result = 0;
		String query = "DELETE FROM mm WHERE mid=?";
		
		try {
			conn = DriverManager.getConnection(url, user, password);
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, mid);			
			
			result = pstmt.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			result = -1;
			
			try {
				conn.rollback();
			} catch (SQLException e1) {
				//e1.printStackTrace();
				result = -1;
			}
		} finally {
			close();
		}
		
		return result;
	}

	//접속 해제를 위한 작업용 메소드
	private void close() {
		//ResultSet -> Statement -> Connection 순으로 close.
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (SQLException e) {
			//보통 작성 안함.
		}
	}
}







