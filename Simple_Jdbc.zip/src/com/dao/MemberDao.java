package com.dao;

import java.util.List;

import com.dto.MemberDto;

//DAO는 DB 연동, SQL 쿼리문 처리만을 위한 메소드를 정의

public interface MemberDao {
	//로그인 처리를 위한 메소드(select)
	public String selectPass(String mid);
	//회원 정보 확인용 메소드(select)
	public MemberDto selectInfo(String mid);
	//모든 회원 정보 확인용 메소드(select)
	public List<MemberDto> selectList();
	//회원 가입용 메소드(insert)
	public int insertMember(MemberDto member);
	//회원 정보 수정용 메소드(update)
	public int updateMember(MemberDto member);
	//회원 정보 삭제용 메소드(delete)
	public int deleteMember(String mid);
}






