package com.view;

import java.util.List;
import java.util.Scanner;

import com.dto.MemberDto;

public class MemberView {

	private Scanner scan = new Scanner(System.in); 

	//로그인 화면 출력 및 입력
	public void loginInput(MemberDto member) {
		while(true) {
			//아이디와 패스 입력 안할 경우 반복
			System.out.println("*** 회원 로그인 ***");

			System.out.print("ID: ");
			member.setMid(scan.nextLine());
			if(member.getMid().equals("")) {
				System.out.println("ID를 입력하세요.");
				continue;//로그인 처리 다시.
			}
			System.out.print("PASS: ");
			member.setMpass(scan.nextLine());
			if(member.getMpass().equals("")) {
				System.out.println("PASS를 입력하세요.");
				continue;//로그인 처리 다시.
			}
			else {//ID, PASS 정상 입력되면 반복 종료.
				break;
			}
		}
	}

	//타이틀과 메인 메뉴를 출력하는 메소드 작성
	public void showMainMenu(String user) {
		System.out.println();
		System.out.println("*** 회원 관리 프로그램 ***");
		System.out.println("==========================");
		System.out.println("메뉴>");
		System.out.println("1. 내 정보 보기");
		System.out.println("2. 내 정보 수정");

		if(user.equals("admin")) {
			System.out.println("3. 회원 전체 보기");
			System.out.println("4. 회원 삭제");
		}

		System.out.println("0. 종료");
		System.out.println("==========================");
		System.out.print("선택>> "); 
	}//showMainMenu 끝

	//번호 받기 메소드
	public int inputNum() {
		//scanner의 문제 
		//번호 뒤에 문자열을 입력받을 때 입력이 안되는 문제
		String str = scan.nextLine();//입력은 문자열로..
		int num = -1;

		//숫자를 입력하지 않고 엔터를 쳤을 때의 예외사항 막기.
		if(!str.equals("")) {
			num = Integer.parseInt(str);
		}

		return num;
	}//숫자 입력 메소드 끝

	public void printMsg(int m) {
		switch(m) {
		case 0://프로그램 종료 메시지
			System.out.println("프로그램 종료합니다.");
			break;
		case 1://이전메뉴 돌아가기 메시지
			System.out.println("이전 메뉴로 돌아갑니다.");
			break;
		case 2://메뉴입력 오류 메시지
			System.out.println("잘못 입력하셨습니다.");
			break;
		case 3://데이터 없음 메시지
			System.out.println("저장된 데이터 없음.");
			break;
		case 4://저장 완료 메시지
			System.out.println("저장 완료.");
			break;
		case 5://삭제 완료 메시지
			System.out.println("삭제 완료.");
			break;
		case 6://검색 결과 없음 메시지
			System.out.println("검색 결과 없음.");
			break;
		case 7://저장 실패 메시지
			System.out.println("저장 실패.");
			break;
		case 8://삭제 실패 메시지
			System.out.println("삭제 실패.");
			break;
		case 9://로그인 실패 메시지
			System.out.println("아이디 없음.");
			break;
		case 10://로그인 실패 메시지
			System.out.println("비밀번호 틀림.");
			break;
		}
		System.out.println();
	}//printMsg 메소드 끝

	public void printInfo(MemberDto member) {
		// 전달받은 회원 인스턴스 출력
		System.out.println("*** 내 정보 보기 ***");
		System.out.println("======================");
		System.out.println(member);
	}

	public void printAll(List<MemberDto> memberList) {
		// TODO Auto-generated method stub
		System.out.println("*** 전체 회원 보기 ***");
		System.out.println("======================");

		for(MemberDto mem : memberList) {
			System.out.println(mem);
		}
	}

	public void updateInput(MemberDto member) {
		// TODO Auto-generated method stub
		System.out.println("*** 내 정보 수정 ***");
		System.out.println("======================");
		System.out.println(member);
		System.out.print("수정하겠습니까(y/n)? ");
		String str = scan.nextLine();

		if(!str.toUpperCase().equals("Y")) {
			return;
		}

		System.out.print("NAME: ");
		str = scan.nextLine();
		if(!str.equals("")) {
			member.setMname(str);
		}
		System.out.print("PASS: ");
		str = scan.nextLine();
		if(!str.equals("")) {
			member.setMpass(str);
		}
	}

	//삭제 ID 입력 메소드
	public String inputDelId(String str) {
		System.out.println("*** 회원 삭제 ***");
		System.out.println("======================");
		System.out.print(str);

		return scan.nextLine();
	}//문자열 입력 메소드 끝

	public void regInput(MemberDto member) {
		System.out.print("회원 가입(y/n)? ");
		String r = scan.nextLine();
		
		if(!r.toUpperCase().equals("Y")) {
			return;
		}
		
		System.out.println("*** 회원 가입 ***");
		System.out.println("======================");
		System.out.println("ID: " + member.getMid());
		System.out.print("NAME: ");
		member.setMname(scan.nextLine());
		System.out.print("PASS: ");
		member.setMpass(scan.nextLine());
	}

}//클래스 끝





