package com;

import com.controller.MemberController;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MemberController mCon = new MemberController();
		mCon.controll();
	}

}
